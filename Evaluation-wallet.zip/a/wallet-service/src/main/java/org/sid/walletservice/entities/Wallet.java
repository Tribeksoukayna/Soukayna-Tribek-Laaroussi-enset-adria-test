package org.sid.walletservice.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;
@Entity
@Data@AllArgsConstructor@NoArgsConstructor@Builder
public class Wallet {
    @Id@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private double solde;
    private Date createdAt;
    private String devise;
    private String clientId;
    @ManyToOne
    private Client client;
}