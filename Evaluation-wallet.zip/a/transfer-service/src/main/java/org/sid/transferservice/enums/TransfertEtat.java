package org.sid.transfertservice.enums;

public enum TransfertEtat {
    PENDING,VALIDATED,REJECTED
}