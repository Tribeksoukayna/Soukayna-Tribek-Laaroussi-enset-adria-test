package org.sid.transfertservice.model;

import java.util.Date;

public class Wallet {
    private Long id;
    private double solde;
    private Date createdAt;
    private String devise;
    private String clientId;
}