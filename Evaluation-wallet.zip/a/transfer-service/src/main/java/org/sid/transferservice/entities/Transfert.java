package org.sid.transferservice.entities;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


import java.util.Date;
@Entity@Data@AllArgsConstructor@NoArgsConstructor@Builder
public class Transfert {
    @Id@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Date createdAt;
    @Transient
    private org.sid.transfertservice.model.Wallet walletSource;
    @Transient
    private org.sid.transfertservice.model.Wallet walletDestination;
    private double montant;
    private org.sid.transfertservice.enums.TransfertEtat etat;
}