package org.sid.transferservice.entities;

import org.springframework.data.rest.core.config.Projection;

import java.util.Date;
@Projection(name = "fullTransfert",types = Transfert.class)
public interface TransfertProjection {
    Long getId();
    Date getCreatedAt();
    double getMontant();
    org.sid.transfertservice.enums.TransfertEtat getEtat();

}